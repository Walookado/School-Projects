/*
*		This code was based upon the OpenGL program framework from
*		Jeff Molofee's tutorials on his website nehe.gamedev.net
*/

#define _USE_MATH_DEFINES
#include <cmath>
#include <windows.h>		// Header File For Windows
#include <stdio.h>			// Header File For Standard Input/Output
#include <ctime>
#include <gl\glew.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include "SOIL.h"
#include "matrixLib.cpp"

HDC			hDC = NULL;		// Private GDI Device Context
HGLRC		hRC = NULL;		// Permanent Rendering Context
HWND		hWnd = NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool	keys[256];			// Array Used For The Keyboard Routine
bool	active = TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen = TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default
bool	light;				// Lighting ON/OFF ( NEW )
bool	lp = true;			// L Pressed? ( NEW )
bool	fp;					// F Pressed? ( NEW )
bool	movement = TRUE;
bool	eSwitch = FALSE;
bool	shot = FALSE;
bool	gameover = FALSE;

const float piover180 = 0.0174532925f;
const float pi = 3.1415926536f;

atoms H;
atoms O;

GLfloat	yrot;						// Y Rotation
GLfloat lookupdown = 0.0f;			// X Rotation
GLfloat diffrot = 0.0f;
GLfloat	z = 0.0f;			// Depth Into The Screen
GLUquadric *quad;			//Object for sphere draws

GLfloat LightAmbient[] = { 10.0f, 10.0f, 10.0f, 1.0f };	//Ambient Light Values
GLfloat LightDiffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };	//Diffuse Light Values
GLfloat LightPosition[] = { 0.0f, 0.0f, 2.0f, 1.0f };	//Diffuse Light Position
GLfloat xpos = 0.0f;									//Camera x position
GLfloat zpos = 0.0f;									//Camera z position
GLfloat xScale = 24.0f;									//x Scale value for 1 section
GLfloat zScale = 16.0f;									//z Scale value for 1 section
GLfloat eOrbitN = 0.0f;
GLfloat eOrbitP = 180.0f;
GLfloat eOrbitT = 0.0f;
GLfloat xP;
GLfloat zP;
GLfloat	health = 100.0f;
GLfloat	prevhp = 100.0f;
GLfloat hpscale = 1.0f;
GLfloat hp;

GLdouble lastShot = GetTickCount();
GLdouble currT;

GLuint	filter;						// Which Filter To Use
GLuint	texture[13];					// Storage For 3 Textures
GLuint	listH, listO, listE, listE2;		//Draw Lists
GLuint	sections = 10;				//Number of sections to draw for the grid
GLuint	oxygens = 8;				//Number of oxygen atoms
GLuint	hydrogens = oxygens * 4;				//Number of hydrogen atoms must be twice the number of oxygens for water to form
GLuint	seed = time(0);
GLuint	ammo = 20;
GLuint	screen = 0;

GLint	hydroE = 1;					//Total electrons per hydrogen
GLint	oxyE = 8;					//Total electrons per oxygen

std::vector<GLfloat> mapBound;							//Vector to hold map boundaries

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

struct projectile
{
	GLfloat xP, zP, xMin, xMax, zMin, zMax, angle;
	GLboolean fired, angSet, alive;
};

struct projectiles
{
	std::vector<projectile> shots;
};

projectiles P;

void setBound(GLuint sections, GLfloat x, GLfloat z)	//Map bounds based upon specified sections for the grid and default size of each section.
{
	GLfloat xMin, xMax, zMin, zMax, yMin;
	yMin = -6.0f;
	xMax = x * ((GLfloat)sections / 2);
	xMin = -xMax / 2;
	zMax = z * ((GLfloat)sections / 2);
	zMin = -zMax / 2;
	mapBound = { xMin, xMax, zMin, zMax, yMin };
}

projectiles initP(projectiles p)
{
	projectile empty;
	for (GLuint i = 0; i < ammo; ++i)
	{
		p.shots.push_back(empty);
	}
	return p;
}

projectiles setP(projectiles p)
{
	for (GLuint i = 0; i < p.shots.size(); ++i)
	{
		p.shots[i].xP = -xpos + 2.0f;
		p.shots[i].zP = -zpos + 2.0f;
		p.shots[i].xMin = p.shots[i].xP - 2.0f;
		p.shots[i].xMax = p.shots[i].xP + 2.0f;
		p.shots[i].zMin = p.shots[i].zP - 2.0f;
		p.shots[i].zMax = p.shots[i].zP + 2.0f;
		p.shots[i].angle = yrot;
		p.shots[i].fired = FALSE;
		p.shots[i].angSet = FALSE;
		p.shots[i].alive = TRUE;
	}
	return p;
}

atoms initA(atoms A, GLint num)
{
	atom empty;
	for (int i = 0; i < num; ++i)
	{
		A.a.push_back(empty);
	}
	return A;
}

GLint initDList(GLuint list, GLint len, GLUquadric *quad)//Initialize draw lists for atoms and their electrons
{
	for (GLint i = 0; i < len; ++i)
	{
		gluQuadricDrawStyle(quad, GLU_FILL);
		gluQuadricNormals(quad, GLU_SMOOTH);
		gluQuadricOrientation(quad, GLU_OUTSIDE);
		gluQuadricTexture(quad, GLU_TRUE);
		glNewList(list + i, GL_COMPILE);
		gluSphere(quad, 1.0, 100, 100);
		glEndList();
	}
	return list;
}

atoms setPos(atoms A)									//Set random start positions for every atom
{
	GLint xRange = (GLint)((bounds[1] * 1.5f) - (bounds[0] * 2.0f));
	GLint zRange = (GLint)((bounds[3] * 1.5f) - (bounds[2] * 2.0f));
	for (GLuint i = 0; i < A.a.size(); ++i)
	{
		A.a[i].xPos = rand() % xRange - bounds[1];
		A.a[i].zPos = rand() % zRange - bounds[3];
		A.a[i].xMove = (static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / 0.1f))) + 0.01f;
		A.a[i].zMove = (static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / 0.1f))) + 0.01f;
	}
	return A;
}

atoms initH(atoms H, GLint numH)						//Initialize the variables for every hydrogen atom
{
	for (int i = 0; i < numH; ++i)
	{
		H.a[i].innerE = 1;
		H.a[i].outerE = 0;
		H.a[i].emptyE = 0;
		H.a[i].numA = numH;
		H.a[i].xMove = 0.0f;
		H.a[i].zMove = 0.0f;
		H.a[i].orbit = 10.0f;
		H.a[i].drad = 0.5f;
		H.a[i].alive = TRUE;
		H.a[i].boundCheck = TRUE;
		H.a[i].bonded = FALSE;
		H.a[i].xMin = H.a[i].xPos - 2.0f;
		H.a[i].xMax = H.a[i].xPos + 2.0f;
		H.a[i].zMin = H.a[i].zPos - 2.0f;
		H.a[i].zMax = H.a[i].zPos + 2.0f;
		H.a[i].eFallSpeed.resize(H.a[i].innerE);
		H.a[i].eHeight.resize(H.a[i].innerE);
	}
	H = setPos(H);

	return H;
}

atoms initO(atoms O, GLint numO)					//Initialize the variable for every oxygen atom
{
	for (int i = 0; i < numO; ++i)
	{
		O.a[i].innerE = 2;
		O.a[i].outerE = 6;
		O.a[i].emptyE = 2;
		O.a[i].numA = numO;
		O.a[i].xMove = 0.0f;
		O.a[i].zMove = 0.0f;
		O.a[i].orbit = 10.0f;
		O.a[i].drad = 0.5f;
		O.a[i].drad = 1.0f;
		O.a[i].alive = TRUE;
		O.a[i].xMin = O.a[i].xPos - 3.0f;
		O.a[i].xMax = O.a[i].xPos + 3.0f;
		O.a[i].zMin = O.a[i].zPos - 3.0f;
		O.a[i].zMax = O.a[i].zPos + 3.0f;
		O.a[i].eFallSpeed.resize(O.a[i].innerE + O.a[i].outerE);
		O.a[i].eHeight.resize(O.a[i].innerE + O.a[i].outerE);
		O.a[i].extraE.resize(1);
	}
	O = setPos(O);

	return O;
}

void orbitSet(atoms &O, atoms &H)
{
	for (GLuint i = 0; i < H.a.size(); ++i)
	{
		H.a[i].orbit += 2.0f;
	}
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].orbit >= 359.0f)
		{
			O.a[i].orbit = 0.0f;
		}
		O.a[i].orbit += 2.0f;
	}
	eOrbitN -= 2.0f;
	eOrbitP += 2.0f;
	eOrbitT += 2.0f;
}

void moveIt(atoms &O, atoms &H, projectiles &P, GLfloat rot, GLfloat x, GLfloat z)
{
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].alive == TRUE)
		{
			if (O.a[i].xPos >= (mapBound[1] * 1.5f))
			{
				O.a[i].xMove = -O.a[i].xMove;
			}
			if (O.a[i].xPos <= mapBound[0] * 2.0f)
			{
				O.a[i].xMove = -O.a[i].xMove;
			}
			if (O.a[i].zPos >= mapBound[3] * 1.5f)
			{
				O.a[i].zMove = -O.a[i].zMove;
			}
			if (O.a[i].zPos <= mapBound[2] * 2.0f)
			{
				O.a[i].zMove = -O.a[i].zMove;
			}
			O.a[i].xPos += O.a[i].xMove;
			O.a[i].zPos += O.a[i].zMove;
			O.a[i].xMin = O.a[i].xPos - 3.0f;
			O.a[i].xMax = O.a[i].xPos + 3.0f;
			O.a[i].zMin = O.a[i].zPos - 3.0f;
			O.a[i].zMax = O.a[i].zPos + 3.0f;
		}
	}
	for (GLuint i = 0; i < H.a.size(); ++i)
	{
		if (H.a[i].alive == TRUE)
		{
			if (H.a[i].boundCheck == TRUE)
			{
				if (H.a[i].xPos >= (mapBound[1] * 1.5f))
				{
					H.a[i].xMove = -H.a[i].xMove;
				}
				if (H.a[i].xPos <= mapBound[0] * 2.0f)
				{
					H.a[i].xMove = -H.a[i].xMove;
				}
				if (H.a[i].zPos >= mapBound[3] * 1.5f)
				{
					H.a[i].zMove = -H.a[i].zMove;
				}
				if (H.a[i].zPos <= mapBound[2] * 2.0f)
				{
					H.a[i].zMove = -H.a[i].zMove;
				}
			}
			H.a[i].xPos += H.a[i].xMove;
			H.a[i].zPos += H.a[i].zMove;
			H.a[i].xMin = H.a[i].xPos - 2.0f;
			H.a[i].xMax = H.a[i].xPos + 2.0f;
			H.a[i].zMin = H.a[i].zPos - 2.0f;
			H.a[i].zMax = H.a[i].zPos + 2.0f;
		}
	}
	for (GLuint i = 0; i < P.shots.size(); ++i)
	{
		if (P.shots[i].fired == TRUE && P.shots[i].angSet == FALSE && P.shots[i].alive == TRUE)
		{
			P.shots[i].angSet = TRUE;
			P.shots[i].angle = rot;
			P.shots[i].xP -= (float)sin(P.shots[i].angle * piover180) * 0.5f;
			P.shots[i].zP -= (float)cos(P.shots[i].angle * piover180) * 0.5f;
		}
		else if (P.shots[i].fired == TRUE && P.shots[i].angSet == TRUE && P.shots[i].alive == TRUE)
		{
			P.shots[i].xP -= (float)sin(P.shots[i].angle * piover180) * 0.5f;
			P.shots[i].zP -= (float)cos(P.shots[i].angle * piover180) * 0.5f;
		}
		else
		{
			P.shots[i].angle = rot;
			P.shots[i].xP = x;
			P.shots[i].zP = z;
		}
		P.shots[i].xMin = P.shots[i].xP - 2.0f;
		P.shots[i].xMax = P.shots[i].xP + 2.0f;
		P.shots[i].zMin = P.shots[i].zP - 2.0f;
		P.shots[i].zMax = P.shots[i].zP + 2.0f;
	}
}

void drawExplosion(GLfloat x, GLfloat z, GLuint j, atoms &a)
{
	if (a.a[j].drad <= 6.0f && a.a[j].alive == FALSE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[7]);
		glPushMatrix();
		glTranslatef(x, 0.0f, z);
		glScalef(a.a[j].drad, a.a[j].drad, a.a[j].drad);
		glRotatef(eOrbitP, 1.0f, 1.0f, 1.0f);
		glCallList(listO);
		glPopMatrix();
	}
}

void drawExplosion2(GLfloat x, GLfloat z, GLuint j, atoms &a)
{
	if (a.a[j].crad <= 20.0f && a.a[j].alive == TRUE && O.a[j].recentB == TRUE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[2]);
		glPushMatrix();
		glTranslatef(x, 0.0f, z);
		glScalef(a.a[j].crad, a.a[j].crad, a.a[j].crad);
		glRotatef(eOrbitP, 1.0f, 1.0f, 1.0f);
		glCallList(listO);
		glPopMatrix();
	}
}

void drawH(GLuint texture[], GLuint list, GLuint listE, atoms H)
{
	for (GLuint i = 0; i < H.a.size(); ++i)
	{
		if (H.a[i].alive == TRUE && H.a[i].bonded == FALSE)
		{
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(H.a[i].xPos, 0.0f, H.a[i].zPos);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-H.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list + i);
			glRotatef(H.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glScalef(1 / 0.5f, 1 / 0.5f, 1 / 0.5f);

			glBindTexture(GL_TEXTURE_2D, texture[3]);
			glRotatef(H.a[i].orbit, 0.0f, 1.0f, -1.0f);
			glTranslatef(1.0f, 0.0f, 0.0f);
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(H.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE);
			glPopMatrix();
		}
		else if (H.a[i].alive == FALSE)
		{
			drawExplosion(H.a[i].xPos, H.a[i].zPos, i, H);
		}
	}
}

void drawO(GLuint texture[], GLuint list, GLuint listE, atoms O, GLuint list2)
{
	if (eOrbitT >= 359.0f)
	{
		eOrbitT = 0.0f;
		eSwitch = !eSwitch;
	}
	if (eOrbitP >= 359.0f)
	{
		eOrbitP = 0.0f;
	}
	if (eOrbitN >= 359.0f)
	{
		eOrbitN = 0.0f;
	}
	GLuint E = O.a[0].innerE + O.a[0].outerE;
	GLfloat swap = 1.0f;
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].alive == TRUE && O.a[i].emptyE == 2)
		{
			glBindTexture(GL_TEXTURE_2D, texture[2]);
			glPushMatrix();
			glTranslatef(O.a[i].xPos, 0.0f, O.a[i].zPos);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list + i);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);

			for (GLuint j = 0; j < E; ++j)
			{
				glPushMatrix();
				if (j < O.a[i].innerE)
				{
					if (j == 0)
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
					else
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(-1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
				}
				else
				{
					glBindTexture(GL_TEXTURE_2D, texture[4]);
					if (j < 4)
					{
						glRotatef(H.a[i].orbit, 0.0f, 1.0f, 1.0f);
						glTranslatef(swap * 2.5f, 0.0f, 0.0f);
						swap = -swap;
					}
					else if (j < 6 && j >= 4)
					{
						glRotatef(H.a[i].orbit, 1.0f, 0.0f, 1.0f);
						glTranslatef(0.0f, swap * 2.5f, 0.0f);
						swap = -swap;
					}
					else
					{
						glRotatef(H.a[i].orbit, 1.0f, 1.0f, 0.0f);
						glTranslatef(0.0f, 0.0f, swap * 2.5f);
						swap = -swap;
					}
					glScalef(0.25f, 0.25f, 0.25f);
					glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
					glCallList(listE + j);
				}
				glPopMatrix();
			}
			glPopMatrix();
		}
		else if (O.a[i].alive == TRUE && O.a[i].emptyE == 1 && O.a[i].recentB == FALSE)
		{
			glBindTexture(GL_TEXTURE_2D, texture[2]);
			glPushMatrix();
			glTranslatef(O.a[i].xPos, 0.0f, O.a[i].zPos);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list + i);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);

			for (GLuint j = 0; j < E; ++j)
			{
				glPushMatrix();
				if (j < O.a[i].innerE)
				{
					if (j == 0)
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
					else
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(-1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
				}
				else
				{
					glBindTexture(GL_TEXTURE_2D, texture[4]);
					if (j < 4)
					{
						glRotatef(H.a[i].orbit, 0.0f, 1.0f, 1.0f);
						glTranslatef(swap * 2.5f, 0.0f, 0.0f);
						swap = -swap;
					}
					else if (j < 6 && j >= 4)
					{
						glRotatef(H.a[i].orbit, 1.0f, 0.0f, 1.0f);
						glTranslatef(0.0f, swap * 2.5f, 0.0f);
						swap = -swap;
					}
					else
					{
						glRotatef(H.a[i].orbit, 1.0f, 1.0f, 0.0f);
						glTranslatef(0.0f, 0.0f, swap * 2.5f);
						swap = -swap;
					}
					glScalef(0.25f, 0.25f, 0.25f);
					glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
					glCallList(listE + j);
				}
				glPopMatrix();
			}

			glPushMatrix();
			glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(3.5f, 0.0f, 0.0f);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list2 + i);
			glPopMatrix();

			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[3]);
			if (eSwitch == TRUE)
			{
				glRotatef(eOrbitN, 0.0f, 1.0f, 0.0f);
				glTranslatef(1.5f, 0.0f, 0.0f);
			}
			else if (eSwitch == FALSE)
			{
				glTranslatef(3.5f, 0.0f, 0.0f);
				glRotatef(eOrbitP, 0.0f, 1.0f, 0.0f);
				glTranslatef(2.0f, 0.0f, 0.0f);
			}
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE2);
			glPopMatrix();
			glPopMatrix();
			glPopMatrix();
		}
		else if (O.a[i].alive == TRUE && O.a[i].emptyE == 1 && O.a[i].recentB == TRUE)
		{
			drawExplosion2(O.a[i].xPos, O.a[i].zPos, i, O);
			glBindTexture(GL_TEXTURE_2D, texture[2]);
			glPushMatrix();
			glTranslatef(O.a[i].xPos, 0.0f, O.a[i].zPos);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list + i);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);

			for (GLuint j = 0; j < E; ++j)
			{
				glPushMatrix();
				if (j < O.a[i].innerE)
				{
					if (j == 0)
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
					else
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(-1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
				}
				else
				{
					glBindTexture(GL_TEXTURE_2D, texture[4]);
					if (j < 4)
					{
						glRotatef(H.a[i].orbit, 0.0f, 1.0f, 1.0f);
						glTranslatef(swap * 2.5f, 0.0f, 0.0f);
						swap = -swap;
					}
					else if (j < 6 && j >= 4)
					{
						glRotatef(H.a[i].orbit, 1.0f, 0.0f, 1.0f);
						glTranslatef(0.0f, swap * 2.5f, 0.0f);
						swap = -swap;
					}
					else
					{
						glRotatef(H.a[i].orbit, 1.0f, 1.0f, 0.0f);
						glTranslatef(0.0f, 0.0f, swap * 2.5f);
						swap = -swap;
					}
					glScalef(0.25f, 0.25f, 0.25f);
					glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
					glCallList(listE + j);
				}
				glPopMatrix();
			}

			glPushMatrix();
			glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(3.5f, 0.0f, 0.0f);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list2 + i);
			glPopMatrix();

			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[3]);
			if (eSwitch == TRUE)
			{
				glRotatef(eOrbitN, 0.0f, 1.0f, 0.0f);
				glTranslatef(1.5f, 0.0f, 0.0f);
			}
			else if (eSwitch == FALSE)
			{
				glTranslatef(3.5f, 0.0f, 0.0f);
				glRotatef(eOrbitP, 0.0f, 1.0f, 0.0f);
				glTranslatef(2.0f, 0.0f, 0.0f);
			}
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE2);
			glPopMatrix();
			glPopMatrix();
			glPopMatrix();
		}
		else if (O.a[i].alive == TRUE && O.a[i].emptyE == 0 && O.a[i].recentB == FALSE)
		{
			glBindTexture(GL_TEXTURE_2D, texture[2]);
			glPushMatrix();
			glTranslatef(O.a[i].xPos, 0.0f, O.a[i].zPos);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list + i);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);

			for (GLuint j = 0; j < E; ++j)
			{
				glPushMatrix();
				if (j < O.a[i].innerE)
				{
					if (j == 0)
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
					else
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(-1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
				}
				else
				{
					glBindTexture(GL_TEXTURE_2D, texture[4]);
					if (j < 4)
					{
						glRotatef(H.a[i].orbit, 0.0f, 1.0f, 1.0f);
						glTranslatef(swap * 2.5f, 0.0f, 0.0f);
						swap = -swap;
					}
					else if (j < 6 && j >= 4)
					{
						glRotatef(H.a[i].orbit, 1.0f, 0.0f, 1.0f);
						glTranslatef(0.0f, swap * 2.5f, 0.0f);
						swap = -swap;
					}
					else
					{
						glRotatef(H.a[i].orbit, 1.0f, 1.0f, 0.0f);
						glTranslatef(0.0f, 0.0f, swap * 2.5f);
						swap = -swap;
					}
					glScalef(0.25f, 0.25f, 0.25f);
					glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
					glCallList(listE + j);
				}
				glPopMatrix();
			}

			glPushMatrix();
			glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(3.5f, 0.0f, 0.0f);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list2 + i);
			glPopMatrix();

			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[3]);
			if (eSwitch == TRUE)
			{
				glRotatef(eOrbitN, 0.0f, 1.0f, 0.0f);
				glTranslatef(1.5f, 0.0f, 0.0f);
			}
			else if (eSwitch == FALSE)
			{
				glTranslatef(3.5f, 0.0f, 0.0f);
				glRotatef(eOrbitP, 0.0f, 1.0f, 0.0f);
				glTranslatef(2.0f, 0.0f, 0.0f);
			}
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE2);
			glPopMatrix();
			glPopMatrix();

			glPushMatrix();
			glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(3.5f, 0.0f, 0.0f);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list2 + i);
			glPopMatrix();

			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[3]);
			if (eSwitch == TRUE)
			{
				glRotatef(eOrbitN, 0.0f, 1.0f, 0.0f);
				glTranslatef(1.5f, 0.0f, 0.0f);
			}
			else if (eSwitch == FALSE)
			{
				glTranslatef(3.5f, 0.0f, 0.0f);
				glRotatef(eOrbitP, 0.0f, 1.0f, 0.0f);
				glTranslatef(2.0f, 0.0f, 0.0f);
			}
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE2);
			glPopMatrix();
			glPopMatrix();
			glPopMatrix();
		}
		else if (O.a[i].alive == TRUE && O.a[i].emptyE == 0 && O.a[i].recentB == TRUE)
		{
			drawExplosion2(O.a[i].xPos, O.a[i].zPos, i, O);
			glBindTexture(GL_TEXTURE_2D, texture[2]);
			glPushMatrix();
			glTranslatef(O.a[i].xPos, 0.0f, O.a[i].zPos);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list + i);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);

			for (GLuint j = 0; j < E; ++j)
			{
				glPushMatrix();
				if (j < O.a[i].innerE)
				{
					if (j == 0)
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
					else
					{
						glBindTexture(GL_TEXTURE_2D, texture[3]);
						glRotatef(H.a[i].orbit, 0.0f, -1.0f, 1.0f);
						glTranslatef(-1.5f, 0.0f, 0.0f);
						glScalef(0.25f, 0.25f, 0.25f);
						glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
						glCallList(listE + j);
					}
				}
				else
				{
					glBindTexture(GL_TEXTURE_2D, texture[4]);
					if (j < 4)
					{
						glRotatef(H.a[i].orbit, 0.0f, 1.0f, 1.0f);
						glTranslatef(swap * 2.5f, 0.0f, 0.0f);
						swap = -swap;
					}
					else if (j < 6 && j >= 4)
					{
						glRotatef(H.a[i].orbit, 1.0f, 0.0f, 1.0f);
						glTranslatef(0.0f, swap * 2.5f, 0.0f);
						swap = -swap;
					}
					else
					{
						glRotatef(H.a[i].orbit, 1.0f, 1.0f, 0.0f);
						glTranslatef(0.0f, 0.0f, swap * 2.5f);
						swap = -swap;
					}
					glScalef(0.25f, 0.25f, 0.25f);
					glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
					glCallList(listE + j);
				}
				glPopMatrix();
			}

			glPushMatrix();
			glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(3.5f, 0.0f, 0.0f);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list2 + i);
			glPopMatrix();

			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[3]);
			if (eSwitch == TRUE)
			{
				glRotatef(eOrbitN, 0.0f, 1.0f, 0.0f);
				glTranslatef(1.5f, 0.0f, 0.0f);
			}
			else if (eSwitch == FALSE)
			{
				glTranslatef(3.5f, 0.0f, 0.0f);
				glRotatef(eOrbitP, 0.0f, 1.0f, 0.0f);
				glTranslatef(2.0f, 0.0f, 0.0f);
			}
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE2);
			glPopMatrix();
			glPopMatrix();

			glPushMatrix();
			glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
			glBindTexture(GL_TEXTURE_2D, texture[1]);
			glPushMatrix();
			glTranslatef(3.5f, 0.0f, 0.0f);
			glScalef(0.5f, 0.5f, 0.5f);
			glRotatef(-O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list2 + i);
			glPopMatrix();

			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[3]);
			if (eSwitch == TRUE)
			{
				glRotatef(eOrbitN, 0.0f, 1.0f, 0.0f);
				glTranslatef(1.5f, 0.0f, 0.0f);
			}
			else if (eSwitch == FALSE)
			{
				glTranslatef(3.5f, 0.0f, 0.0f);
				glRotatef(eOrbitP, 0.0f, 1.0f, 0.0f);
				glTranslatef(2.0f, 0.0f, 0.0f);
			}
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(O.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(listE2);
			glPopMatrix();
			glPopMatrix();
			glPopMatrix();
		}
		else
		{
			drawExplosion(O.a[i].xPos, O.a[i].zPos, i, O);
		}
	}
}

void drawP(GLuint texture[], GLuint list, projectiles p)
{
	for (GLuint i = 0; i < p.shots.size(); ++i)
	{
		if (p.shots[i].fired == TRUE && p.shots[i].alive == TRUE && i == 0)
		{
			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[6]);
			glTranslatef(p.shots[i].xP, -1.0f, p.shots[i].zP);
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(-H.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list);
			glPopMatrix();
		}
		else if (p.shots[i].fired == TRUE && p.shots[i].alive == TRUE)
		{
			glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texture[6]);
			glTranslatef(p.shots[i].xP, -1.0f, p.shots[i].zP);
			glScalef(0.25f, 0.25f, 0.25f);
			glRotatef(-H.a[i].orbit, 1.0f, 1.0f, 1.0f);
			glCallList(list);
			glPopMatrix();
		}
	}
}

void drawTank(GLuint texture[], GLfloat xtrans, GLfloat ztrans)
{
	glBindTexture(GL_TEXTURE_2D, texture[5]);

	glPushMatrix();
	glTranslatef(0, -1.6f, -6.0f);
	glScalef(0.5f, 0.35f, 0.5f);
	cubeIt(texture, 5);

	glTranslatef(0, 0, -5.0f);
	glScalef(0.5, 0.375, 4.0f);
	cubeIt(texture, 5);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, -3.0f, -6.0f);
	glScalef(1.5f, 1.0f, 1.5f);
	glRotatef(-yrot + diffrot / 2.0f, 0.0, 1.0f, 0.0f);
	trapezoid(texture, 5);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, -4.5f, -6.0f);
	glScalef(1.5f, 0.5f, 1.5f);
	glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(-yrot + diffrot / 2.0f, 0.0, 1.0f, 0.0f);
	trapezoid(texture, 5);
	glPopMatrix();
}

void drawScreen(GLuint texture[], GLuint screenNum)
{
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, texture[screenNum]);

	glBegin(GL_QUADS);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -2.5f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, -1.0f, -2.5f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, -2.5f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -2.5f);
	glEnd();
	glPopMatrix();
}

void drawHP(GLuint texture[])
{
	hp = health / 100.0f;

	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, texture[11]);

	glBegin(GL_QUADS);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.08f, -0.015f, -1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0.08f, -0.015f, -1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(0.08f, 0.015f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.08f, 0.015f, -1.0f);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, texture[12]);
	glScalef(hp, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.078f, -0.013f, -1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(0.078f, -0.013f, -1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(0.078f, 0.013f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.078f, 0.013f, -1.0f);
	glEnd();
	glPopMatrix();
}

void xhair()
{
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glBegin(GL_LINES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3d(0.0f, 0.05f, -1.0f);
	glVertex3d(0.0f, 0.025f, -1.0f);

	glVertex3d(0.0f, -0.05f, -1.0f);
	glVertex3d(0.0f, -0.025f, -1.0f);

	glVertex3d(0.05f, 0.0f, -1.0f);
	glVertex3d(0.025f, 0.0f, -1.0f);

	glVertex3d(-0.05f, 0.0f, -1.0f);
	glVertex3d(-0.025f, 0.0f, -1.0f);
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

projectiles shotUpdate(projectiles P)
{
	lastShot = GetTickCount();
	ammo--;
	GLuint currAm = 20 - ammo;
	if (currAm < P.shots.size())
	{
		for (GLuint i = 0; i < currAm; ++i)
		{
			if (P.shots[i].fired == FALSE)
			{
				P.shots[i].xP -= (float)sin(P.shots[i].angle * piover180) * 10.0f;
				P.shots[i].zP -= (float)cos(P.shots[i].angle * piover180) * 10.0f;
				P.shots[i].fired = TRUE;
			}
		}
	}
	return P;
}

void collisionCheck()
{
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		for (GLuint j = 0; j < H.a.size(); ++j)
		{
			if ((((O.a[i].xMax >= H.a[j].xMin && O.a[i].xMax <= H.a[j].xMax) && (O.a[i].zMax >= H.a[j].zMin && O.a[i].zMax <= H.a[j].zMax))
				|| ((O.a[i].xMax >= H.a[j].xMin && O.a[i].xMax <= H.a[j].xMax) && (O.a[i].zMin <= H.a[j].zMax && O.a[i].zMin >= H.a[j].zMin))
				|| ((O.a[i].xMin <= H.a[j].xMax && O.a[i].xMin >= H.a[j].xMin) && (O.a[i].zMax >= H.a[j].zMin && O.a[i].zMax <= H.a[j].zMax))
				|| ((O.a[i].xMin <= H.a[j].xMax && O.a[i].xMin >= H.a[j].xMin) && (O.a[i].zMin <= H.a[j].zMax && O.a[i].zMin >= H.a[j].zMin))) && O.a[i].emptyE > 0
				&& O.a[i].alive == TRUE && H.a[j].alive == TRUE && H.a[j].bonded == FALSE)
			{
				H.a[j].bonded = TRUE;
				if (O.a[i].emptyE == 2)
				{
					if (O.a[i].extraE[0] != j && O.a[i].extraE.size() == 1)
					{
						O.a[i].extraE[0] = j;
						O.a[i].emptyE = 1;
						O.a[i].recentB = TRUE;
						health = health - (100.0f / (4.0f * (GLfloat)oxygens));
					}
				}
				else if (O.a[i].emptyE == 1)
				{
					if (O.a[i].extraE[0] != j && O.a[i].extraE.size() == 1)
					{
						O.a[i].emptyE = 0;
						O.a[i].recentB = TRUE;
						O.a[i].lastdmg = GetTickCount();
						health = health - (100.0f / (4.0f * (GLfloat)oxygens));
					}
				}
			}
		}
	}
	for (GLuint i = 0; i < P.shots.size(); ++i)
	{
		if (P.shots[i].fired == TRUE)
		{
			for (GLuint j = 0; j < H.a.size(); ++j)
			{
				if ((((P.shots[i].xMax >= H.a[j].xMin && P.shots[i].xMax <= H.a[j].xMax) && (P.shots[i].zMax >= H.a[j].zMin && P.shots[i].zMax <= H.a[j].zMax))
					|| ((P.shots[i].xMax >= H.a[j].xMin && P.shots[i].xMax <= H.a[j].xMax) && (P.shots[i].zMin <= H.a[j].zMax && P.shots[i].zMin >= H.a[j].zMin))
					|| ((P.shots[i].xMin <= H.a[j].xMax && P.shots[i].xMin >= H.a[j].xMin) && (P.shots[i].zMax >= H.a[j].zMin && P.shots[i].zMax <= H.a[j].zMax))
					|| ((P.shots[i].xMin <= H.a[j].xMax && P.shots[i].xMin >= H.a[j].xMin) && (P.shots[i].zMin <= H.a[j].zMax && P.shots[i].zMin >= H.a[j].zMin)))
					&& P.shots[i].alive == TRUE && H.a[j].alive == TRUE && H.a[j].bonded == FALSE)
				{
					H.a[j].alive = FALSE;
					P.shots[i].alive = FALSE;
				}
			}
			for (GLuint j = 0; j < O.a.size(); ++j)
			{
				if ((((P.shots[i].xMax >= O.a[j].xMin && P.shots[i].xMax <= O.a[j].xMax) && (P.shots[i].zMax >= O.a[j].zMin && P.shots[i].zMax <= O.a[j].zMax))
					|| ((P.shots[i].xMax >= O.a[j].xMin && P.shots[i].xMax <= O.a[j].xMax) && (P.shots[i].zMin <= O.a[j].zMax && P.shots[i].zMin >= O.a[j].zMin))
					|| ((P.shots[i].xMin <= O.a[j].xMax && P.shots[i].xMin >= O.a[j].xMin) && (P.shots[i].zMax >= O.a[j].zMin && P.shots[i].zMax <= O.a[j].zMax))
					|| ((P.shots[i].xMin <= O.a[j].xMax && P.shots[i].xMin >= O.a[j].xMin) && (P.shots[i].zMin <= O.a[j].zMax && P.shots[i].zMin >= O.a[j].zMin)))
					&& P.shots[i].alive == TRUE && O.a[j].alive == TRUE)
				{
					O.a[j].alive = FALSE;
					P.shots[i].alive = FALSE;
				}
			}
		}
	}
}

void dmgCheck()
{
	GLdouble currT = GetTickCount();
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].emptyE == 0 && (currT - O.a[i].lastdmg) >= 5000 && O.a[i].recentB == FALSE)
		{
			health = health - (100.0f / (4.0f * (GLfloat)oxygens));
			O.a[i].recentB = TRUE;
			O.a[i].crad = 1.0f;
			O.a[i].lastdmg = currT;
		}
	}
}

void explosionUp(atoms &O, atoms &H)
{
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].alive == FALSE && O.a[i].drad <= 6.0f)
		{
			O.a[i].drad += 0.5f;
		}
	}
	for (GLuint i = 0; i < H.a.size(); ++i)
	{
		if (H.a[i].alive == FALSE && H.a[i].drad <= 6.0f)
		{
			H.a[i].drad += 0.5f;
		}
	}
}

void explosion2Up(atoms &O)
{
	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].alive == TRUE && O.a[i].crad <= 20.0f && O.a[i].recentB == TRUE)
		{
			O.a[i].crad += 0.5f;
		}
		else
		{
			O.a[i].recentB = FALSE;
			O.a[i].crad = 1.0f;
		}
	}
}

void winCheck()
{
	bool win = FALSE;
	GLuint deadO = 0;
	GLuint deadH = 0;

	for (GLuint i = 0; i < O.a.size(); ++i)
	{
		if (O.a[i].alive == FALSE)
		{
			deadO++;
		}
	}
	for (GLuint i = 0; i < H.a.size(); ++i)
	{
		if (H.a[i].alive == FALSE)
		{
			deadH++;
		}
	}

	if (deadO == oxygens)
	{
		win = TRUE;
	}
	if (deadH == hydrogens)
	{
		win = TRUE;
	}

	if (win == TRUE && gameover == FALSE)
	{
		screen = 2;
		gameover = TRUE;
	}
}

void lossCheck()
{
	if (health <= 0 && gameover == FALSE)
	{
		screen = 3;
		gameover = TRUE;
	}
	if (ammo == 0 && gameover == FALSE)
	{
		screen = 3;
		gameover = TRUE;
	}
}

int LoadGLTextures()								//SOIL based image loading to support multiple image formats
{

	texture[0] = SOIL_load_OGL_texture(
		"Data/thegrid.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[0] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[1] = SOIL_load_OGL_texture(
		"Data/hydrogen2.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[1] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[1]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[2] = SOIL_load_OGL_texture(
		"Data/oxygen.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[2] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[2]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[3] = SOIL_load_OGL_texture(
		"Data/neonred.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[3] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[3]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);


	texture[4] = SOIL_load_OGL_texture(
		"Data/neonblue.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[4] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[4]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[5] = SOIL_load_OGL_texture(
		"Data/yellow.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[5] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[5]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[6] = SOIL_load_OGL_texture(
		"Data/projectile.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[6] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[6]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[7] = SOIL_load_OGL_texture(
		"Data/neongreen.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[7] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[7]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[8] = SOIL_load_OGL_texture(
		"Data/startscreen.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[8] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[8]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[9] = SOIL_load_OGL_texture(
		"Data/winscreen.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[9] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[9]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[10] = SOIL_load_OGL_texture(
		"Data/losescreen.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[10] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[10]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[11] = SOIL_load_OGL_texture(
		"Data/barback.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[11] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[11]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	texture[12] = SOIL_load_OGL_texture(
		"Data/barhp.png",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_MIPMAPS);

	if (texture[12] == 0)
		return false;

	// Define Texture Parameters
	glBindTexture(GL_TEXTURE_2D, texture[12]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);

	return true;
}

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height == 0)										// Prevent A Divide By Zero By
	{
		height = 1;										// Making Height Equal One
	}

	glViewport(0, 0, width, height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	if (!LoadGLTextures())								// Jump To Texture Loading Routine
	{
		return FALSE;									// If Texture Didn't Load Return FALSE
	}

	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION, LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);								// Enable Light One
	//glEnable(GL_LIGHTING);

	srand(seed);
	setBound(sections, xScale, zScale);
	setBounds(mapBound);
	H = initA(H, hydrogens);
	O = initA(O, oxygens);
	P = initP(P);
	P = setP(P);
	H = initH(H, hydrogens);
	O = initO(O, oxygens);
	listH = glGenLists(hydrogens);
	listO = glGenLists(oxygens);
	listE = glGenLists(hydroE + oxyE);
	listE2 = glGenLists(hydroE + oxyE);
	quad = gluNewQuadric();
	listH = initDList(listH, hydrogens, quad);
	listO = initDList(listO, oxygens, quad);
	listE = initDList(listE, hydroE, quad);
	listE2 = initDList(listE2, oxyE, quad);

	return TRUE;										// Initialization Went OK
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
	glLoadIdentity();									// Reset The View

	if (screen == 0)
	{
		drawScreen(texture, 8);
	}
	if (screen == 1)
	{
		GLfloat xtrans = -xpos;
		GLfloat ztrans = -zpos;
		GLfloat ytrans = -0.25f;
		GLfloat sceneroty = 360.0f - yrot;

		glPushMatrix();
		glTranslatef(0, -0.02f, 0);
		xhair();
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.6, -0.35, 0);
		drawHP(texture);
		glPopMatrix();

		drawTank(texture, xtrans, ztrans);

		glRotatef(lookupdown, 1.0f, 0, 0);
		glRotatef(sceneroty, 0, 1.0f, 0);

		glTranslatef(xtrans, 0.0f, ztrans);


		glPushMatrix();
		drawP(texture, listO, P);
		glPopMatrix();

		glPushMatrix();
		drawH(texture, listH, listE, H);
		glPopMatrix();

		glPushMatrix();
		drawO(texture, listO, listE2, O, listH);
		glPopMatrix();

		glPushMatrix();
		thegrid(texture, 0, sections, xScale, zScale);
		glPopMatrix();

		orbitSet(O, H);
		collisionCheck();
		moveIt(O, H, P, yrot, xpos, zpos);
		explosionUp(O, H);
		explosion2Up(O);
	}
	if (screen == 2)
	{
		drawScreen(texture, 9);
	}

	if (screen == 3)
	{
		drawScreen(texture, 10);
	}

	return TRUE;										// Keep Going
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL, 0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL, NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL, "Release Of DC And RC Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL, "Release Rendering Context Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		}
		hRC = NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd, hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL, "Release Device Context Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		hDC = NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL, "Could Not Release hWnd.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		hWnd = NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL", hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL, "Could Not Unregister Class.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		hInstance = NULL;									// Set hInstance To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
*	title			- Title To Appear At The Top Of The Window				*
*	width			- Width Of The GL Window Or Fullscreen Mode				*
*	height			- Height Of The GL Window Or Fullscreen Mode			*
*	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
*	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/

BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left = (long)0;			// Set Left Value To 0
	WindowRect.right = (long)width;		// Set Right Value To Requested Width
	WindowRect.top = (long)0;				// Set Top Value To 0
	WindowRect.bottom = (long)height;		// Set Bottom Value To Requested Height

	fullscreen = fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance = GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc = (WNDPROC)WndProc;					// WndProc Handles Messages
	wc.cbClsExtra = 0;									// No Extra Window Data
	wc.cbWndExtra = 0;									// No Extra Window Data
	wc.hInstance = hInstance;							// Set The Instance
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground = NULL;									// No Background Required For GL
	wc.lpszMenuName = NULL;									// We Don't Want A Menu
	wc.lpszClassName = "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL, "Failed To Register The Window Class.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}

	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize = sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth = width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight = height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel = bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL, "The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?", "NeHe GL", MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
			{
				fullscreen = FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL, "Program Will Now Close.", "ERROR", MB_OK | MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle = WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle = WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle = WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd = CreateWindowEx(dwExStyle,							// Extended Style For The Window
		"OpenGL",							// Class Name
		title,								// Window Title
		dwStyle |							// Defined Window Style
		WS_CLIPSIBLINGS |					// Required Window Style
		WS_CLIPCHILDREN,					// Required Window Style
		0, 0,								// Window Position
		WindowRect.right - WindowRect.left,	// Calculate Window Width
		WindowRect.bottom - WindowRect.top,	// Calculate Window Height
		NULL,								// No Parent Window
		NULL,								// No Menu
		hInstance,							// Instance
		NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Window Creation Error.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd =				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};

	if (!(hDC = GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Create A GL Device Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat = ChoosePixelFormat(hDC, &pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Find A Suitable PixelFormat.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!SetPixelFormat(hDC, PixelFormat, &pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Set The PixelFormat.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC = wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Create A GL Rendering Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!wglMakeCurrent(hDC, hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Activate The GL Rendering Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd, SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Initialization Failed.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

LRESULT CALLBACK WndProc(HWND	hWnd,			// Handle For This Window
	UINT	uMsg,			// Message For This Window
	WPARAM	wParam,			// Additional Message Information
	LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
	case WM_ACTIVATE:							// Watch For Window Activate Message
	{
													if (!HIWORD(wParam))					// Check Minimization State
													{
														active = TRUE;						// Program Is Active
													}
													else
													{
														active = FALSE;						// Program Is No Longer Active
													}

													return 0;								// Return To The Message Loop
	}

	case WM_SYSCOMMAND:							// Intercept System Commands
	{
													switch (wParam)							// Check System Calls
													{
													case SC_SCREENSAVE:					// Screensaver Trying To Start?
													case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
														return 0;							// Prevent From Happening
													}
													break;									// Exit
	}

	case WM_CLOSE:								// Did We Receive A Close Message?
	{
													PostQuitMessage(0);						// Send A Quit Message
													return 0;								// Jump Back
	}

	case WM_KEYDOWN:							// Is A Key Being Held Down?
	{
													keys[wParam] = TRUE;					// If So, Mark It As TRUE
													return 0;								// Jump Back
	}

	case WM_KEYUP:								// Has A Key Been Released?
	{
													keys[wParam] = FALSE;					// If So, Mark It As FALSE
													return 0;								// Jump Back
	}

	case WM_SIZE:								// Resize The OpenGL Window
	{
													ReSizeGLScene(LOWORD(lParam), HIWORD(lParam));  // LoWord=Width, HiWord=Height
													return 0;								// Jump Back
	}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE	hInstance,			// Instance
	HINSTANCE	hPrevInstance,		// Previous Instance
	LPSTR		lpCmdLine,			// Command Line Parameters
	int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	BOOL	done = FALSE;								// Bool Variable To Exit Loop

	// Ask The User Which Screen Mode They Prefer
	if (MessageBox(NULL, "Would You Like To Run In Fullscreen Mode?", "Start FullScreen?", MB_YESNO | MB_ICONQUESTION) == IDNO)
	{
		fullscreen = FALSE;							// Windowed Mode
	}

	// Create Our OpenGL Window
	if (!CreateGLWindow("Attack of the Evil Hydrogen and Oxygen Atoms!", 1280, 720, 16, fullscreen))
	{
		return 0;									// Quit If Window Was Not Created
	}

	while (!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message == WM_QUIT)				// Have We Received A Quit Message?
			{
				done = TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !DrawGLScene()) || keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			{
				done = TRUE;							// ESC or DrawGLScene Signalled A Quit
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
				dmgCheck();
				winCheck();
				lossCheck();
				if (keys[VK_RIGHT])
				{
					if (yrot <= -359.0f)
					{
						yrot = 0.0f;
					}
					yrot -= 1.0f;
				}
				if (keys[VK_LEFT])
				{
					if (yrot >= 359.0f)
					{
						yrot = 0.0f;
					}
					yrot += 1.0f;
				}
				if (keys['S'])
				{
					diffrot = (yrot + yrot);
					xpos += (float)sin(yrot*piover180) * 0.075f;
					zpos += (float)cos(yrot*piover180) * 0.075f;

				}
				if (keys['W'])
				{
					diffrot = (yrot + yrot);
					xpos -= (float)sin(yrot*piover180) * 0.075f;
					zpos -= (float)cos(yrot*piover180) * 0.075f;
				}
				if (keys['A'])
				{
					diffrot = (yrot + 180.0f);
					xpos += (float)sin((yrot - 90.0f)*piover180) * 0.075f;
					zpos += (float)cos((yrot - 90.0f)*piover180) * 0.075f;
				}
				if (keys['D'])
				{
					diffrot = (-yrot - 180.0f);
					xpos -= (float)sin((yrot - 90.0f)*piover180) * 0.075f;
					zpos -= (float)cos((yrot - 90.0f)*piover180) * 0.075f;
				}
				if (keys[VK_SPACE])
				{
					currT = GetTickCount();
					if ((currT - lastShot) >= 2000)
					{
						if (screen == 1)
						{
							P = shotUpdate(P);
						}
					}
				}
				if (keys[VK_RETURN])
				{
					if (screen == 0)
					{
						screen = 1;
					}
				}
				if (keys[VK_F1])						// Is F1 Being Pressed?
				{
					keys[VK_F1] = FALSE;					// If So Make Key FALSE
					KillGLWindow();						// Kill Our Current Window
					fullscreen = !fullscreen;				// Toggle Fullscreen / Windowed Mode
					// Recreate Our OpenGL Window
					if (!CreateGLWindow("Attack of the Evil Hydrogen and Oxygen Atoms!", 1280, 720, 16, fullscreen))
					{
						return 0;						// Quit If Window Was Not Created
					}
				}
			}
		}
	}

	// Shutdown
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}