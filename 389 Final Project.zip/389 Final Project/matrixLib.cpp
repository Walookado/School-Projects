#define nRow 4
#define nCol 4
#define _USE_MATH_DEFINES
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <gl\glew.h>
#include <gl\glut.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <string>
#include <iostream>
#include <iomanip>
#include <vector>

struct matrix;
struct atom;
struct atoms;
void setBounds(std::vector<GLfloat> mapBounds);
void thegrid(GLuint texture[], GLuint filter, int sections, float x, float z);

std::vector<GLfloat> bounds;

struct matrix
{
	std::vector< std::vector<float> > m;

	matrix() : m(nRow, std::vector<float>(nCol)) { }
};

struct atom
{
	GLuint innerE, outerE, emptyE, numA;
	GLfloat orbit, xMove, zMove, xPos, zPos, xMin, xMax, zMin, zMax, currAng, drad, crad;
	GLdouble lastdmg;
	GLboolean alive, boundCheck, bonded, recentB;
	std::vector<GLfloat> eHeight, eFallSpeed, extraE;
};

struct atoms
{
	std::vector<atom> a;
};

void setBounds(std::vector<GLfloat> mapBounds)
{
	bounds = mapBounds;
}

void showMatrix(matrix out)
{
	int lenR = out.m.size();
	int lenC = out.m[0].size();

	for (int i = 0; i < lenR; ++i)
	{
		for (int j = 0; j < lenC; ++j)
		{
			if (j == 0 && i != 0)
			{
				std::cout << "\n";
			}

			std::cout << std::setw(10) << std::left << out.m[i][j] << " ";
		}
	}
	std::cout << "\n\n";
}

void square(matrix sq, float xS, float yS, float xT, float yT, float theta)
{
	/*glTranslatef(xT, yT, 0.0f);
	glScalef(xS, yS, 1.0f);
	glRotatef(theta, 0.0f, 0.0f, 1.0f);
	*/

	glBegin(GL_QUADS);

	glVertex3f(sq.m[0][0], sq.m[0][1], 0.0f);

	glVertex3f(sq.m[1][0], sq.m[1][1], 0.0f);

	glVertex3f(sq.m[2][0], sq.m[2][1], 0.0f);

	glVertex3f(sq.m[3][0], sq.m[3][1], 0.0f);

	glEnd();
}

matrix dSquare()
{
	matrix sqM;
	std::vector< std::vector<float> > sqV;
	sqV.resize(4, std::vector<float>(nCol));
	sqV[0][0] = 0.5f;
	sqV[0][1] = 0.5f;
	sqV[0][2] = 0.0f;
	sqV[0][3] = 1.0f;
	sqV[1][0] = 0.5f;
	sqV[1][1] = -0.5f;
	sqV[1][2] = 0.0f;
	sqV[1][3] = 1.0f;
	sqV[2][0] = -0.5f;
	sqV[2][1] = -0.5f;
	sqV[2][2] = 0.0f;
	sqV[2][3] = 1.0f;
	sqV[3][0] = -0.5f;
	sqV[3][1] = 0.5f;
	sqV[3][2] = 0.0f;
	sqV[3][3] = 1.0f;
	sqM.m = sqV;
	return sqM;
}

matrix dSquare2()
{
	matrix sqM;
	std::vector< std::vector<float> > sqV;
	sqV.resize(4, std::vector<float>(nCol));
	sqV[0][0] = 0.5f;
	sqV[0][1] = 0.5f;
	sqV[0][2] = 0.0f;
	sqV[0][3] = 1.0f;
	sqV[1][0] = -0.5f;
	sqV[1][1] = -0.5f;
	sqV[1][2] = 0.0f;
	sqV[1][3] = 1.0f;
	sqM.m = sqV;
	return sqM;
}

matrix dCube()
{
	matrix cube;
	std::vector< std::vector<float> > cubeV;
	matrix square = dSquare2();
	square.m[0][2] = 0.5f;
	square.m[1][2] = -0.5f;

	for (int i = 0; i < 6; ++i)
	{
		cubeV.push_back(square.m[0]);
		cubeV.push_back(square.m[1]);
	}
	cube.m = cubeV;
	return cube;
}

void trapezoid(GLuint texture[], GLuint filter)
{
	glBindTexture(GL_TEXTURE_2D, texture[filter]);

	glBegin(GL_QUADS);
	// Front Face
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.25f, -1.0f, 2.5f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.25f, -1.0f, 2.5f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, 1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, 1.0f);
	// Back Face
	glNormal3f(0.0f, 0.0f, -1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.25f, -1.0f, -2.5f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(1.25f, -1.0f, -2.5f);
	// Top Face
	glNormal3f(0.0f, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, 1.0f, 1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, 1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
	// Bottom Face
	glNormal3f(0.0f, -1.0f, 0.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.25f, -1.0f, -2.5f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(1.25f, -1.0f, -2.5f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(1.25f, -1.0f, 2.5f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.25f, -1.0f, 2.5f);
	// Right face
	glNormal3f(1.0f, 0.0f, 0.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.25f, -1.0f, -2.5f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 1.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(1.25f, -1.0f, 2.5f);
	// Left Face
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.25f, -1.0f, -2.5f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.25f, -1.0f, 2.5f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, 1.0f, 1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f);
	glEnd();
}

void cubeIt(GLuint texture[], GLuint filter)
{
	glBindTexture(GL_TEXTURE_2D, texture[filter]);

	glBegin(GL_QUADS);
	// Front Face
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, 1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, -1.0f, 1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, 1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, 1.0f);
	// Back Face
	glNormal3f(0.0f, 0.0f, -1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, -1.0f, -1.0f);
	// Top Face
	glNormal3f(0.0f, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, 1.0f, 1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, 1.0f, 1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
	// Bottom Face
	glNormal3f(0.0f, -1.0f, 0.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, -1.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, -1.0f, 1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, 1.0f);
	// Right face
	glNormal3f(1.0f, 0.0f, 0.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(1.0f, -1.0f, -1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 1.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, -1.0f, 1.0f);
	// Left Face
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, 1.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, 1.0f, 1.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f);
	glEnd();
}

matrix spiral(float r)
{
	matrix sp;
	std::vector<float> spV;
	std::vector< std::vector<float> > spV2;
	float x, y, theta = 0.0f;

	glColor3f(1.0f, 0.0f, 1.0f);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < 1024; ++i)
	{
		spV.clear();
		theta = 2.0f * 3.1415926f * i / 64; //the current angle

		x = (r / 1024) * i * cos(theta); //the x component
		y = (r / 1024) * i * sin(theta); //the y component
		spV.push_back(x);
		spV.push_back(y);
		spV.push_back(1.0f);
		spV2.push_back(spV);

		glVertex3f(x, y, 0.0f);
	}
	glEnd();
	sp.m = spV2;
	return sp;
}

void reSpiral(matrix sp, float *color)
{
	int len = sp.m.size();

	glColor3f(color[0], color[1], color[2]);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < len; ++i)
	{
		glVertex3f(sp.m[i][0], sp.m[i][1], 0.0f);
	}
	glEnd();
}

void thegrid(GLuint texture[], GLuint filter, int sections, float x, float z)
{
	GLfloat xS, zS = 0.0f;

	glTranslatef(bounds[0], bounds[4], bounds[2]);
	glBindTexture(GL_TEXTURE_2D, texture[filter]);
	for (int i = 0; i < sections; ++i)
	{
		xS = (float)i;
		for (int j = 0; j < sections; ++j)
		{
			zS = (float)j;
			glPushMatrix();
			glTranslatef(x * xS, 0.0f, z * zS);
			glBegin(GL_QUADS);
			glNormal3f(0.0f, 1.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-x, 0.0f, -z);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-x, 0.0f, z);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(x, 0.0f, z);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(x, 0.0f, -z);
			glEnd();
			glPopMatrix();
		}
	}
}